enemy01　騎士型

武器:buki_J                       操作法;回転 【ジョイント】
肩:kataarmor_Left kataarmor_Right 操作法:回転 【ジョイント】
髪:hair_ctrl                      操作法:移動 【四角い赤ボックス】
スカート:skirt_ctrl 0～4　        操作法:移動 【四角い赤ボックス】

